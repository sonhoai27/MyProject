package com.sonhoai.sonho.draw;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    int bitmapWidth = 300, bitmapHeight = 300;
    private ImageView img;
    private int colQty = 6, rowQty = 6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = findViewById(R.id.img);
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight,Bitmap.Config.ARGB_8888);
        //dai dien cho to giay
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        int celHeight = bitmapHeight/rowQty;
        for(int i = 0; i <= rowQty; i++){
            canvas.drawLine(0,celHeight*i,bitmapHeight,celHeight*i,paint);
        }
        int celWidth = bitmapWidth/colQty;
        for(int i = 0; i < colQty; i++){
            canvas.drawLine(celWidth*i,0,celWidth*i,bitmapWidth,paint);
        }

        img.setImageBitmap(bitmap);
    }

}
